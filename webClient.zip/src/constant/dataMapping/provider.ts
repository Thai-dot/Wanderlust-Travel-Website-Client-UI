const providerConstant = [
    {
        label: 'Khách sạn',
        value: 1
    },
    {
        label: 'Nhà hàng',
        value: 2
    },
    {
        label: 'Vé máy bay',
        value: 3
    },
    {
        label: 'Xe bus',
        value: 4
    },
    {
        label: 'Thuyền',
        value: 5
    },
    {
        label: 'Hướng dẫn viên',
        value: 6
    },
    {
        label: 'Du thuyền',
        value: 7
    },
    {
        label: 'Land tour',
        value: 8
    },
    {
        label: 'Vé thắng cảnh',
        value: 9
    },
    {
        label: 'Tàu lửa',
        value: 10
    }
];

export default providerConstant;
