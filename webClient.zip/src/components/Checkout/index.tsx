import React from "react";
import BookingInfo from "./BookingInfo";
import UserInfo from "./UserInfo";

interface CheckoutProps {}

export const Checkout: React.FC<CheckoutProps> = ({}) => {
  return (
    <div className="booking">
      {/* <UserInfo />
      <BookingInfo /> */}
      test
    </div>
  );
};
