import React from "react";
import Form from "../components/Login-Register/Form";

const RegisterPage = () => {
  return (
    <main className="main-form">
      <Form name="register" type={0} />
    </main>
  );
};

export default RegisterPage;
