export interface Favourite {
  _id?: string;
  user: string;
  hotel: string;
  createdAt?: Date;
  updatedAt?: Date;
}
